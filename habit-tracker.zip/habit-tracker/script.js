function addHabit() {
    const input = document.getElementById("habitInput");
    const list = document.getElementById("habitList");
    if (input.value.trim()) {
        const item = document.createElement("li");
        item.textContent = input.value;
        list.appendChild(item);
        input.value = "";
    }
}