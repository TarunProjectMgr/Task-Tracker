# Habit Tracker

## Description
A simple habit tracker web app to help users build and maintain daily habits.

## Features
- Add a new habit
- View list of habits
- Easy-to-use interface

## Technologies
- HTML
- CSS
- JavaScript

## Project Manager
👤 Tarun Madala

## Status
Basic version complete. Enhancements planned.